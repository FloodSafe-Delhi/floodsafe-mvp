
  # FloodSafe Delhi

  This is a code bundle for FloodSafe Delhi. The original project is available at https://www.figma.com/design/8LfAfqNMF1mEkF9z67KXv0/FloodSafe-Delhi.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  